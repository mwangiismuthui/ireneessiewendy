<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PasswordReseting extends Model
{
    protected $table = 'password_resets';
}
